#!/usr/bin/env python3

from geometry_msgs.msg import Pose, PoseArray, Quaternion
#from pf_localisation.pf_base import PFLocaliserBase
from pf_localisation.pf_base import PFLocaliserBase as PFLocaliserBase

import math
import rospy

from pf_localisation.util import rotateQuaternion, getHeading
from random import random

from time import time


class PFLocaliser(PFLocaliserBase):
       
    def __init__(self):
        # Call the superclass constructor
        super(PFLocaliser, self).__init__()
        
        # Set motion model parameters
 
        # Sensor model parameters
        self.NUMBER_PREDICTED_READINGS = 20 	# Number of readings to predict
        
       
    def initialise_particle_cloud(self, initialpose):

        '''
        This should instantiate and return a PoseArray [3] object, which contains 
        a list of Pose objects. Each of these Poses should be set to a random position and 
        orientation around the initial pose, e.g. by adding a Gaussian random number multiplied by a noise 
        parameter to the initial pose.
        '''
        print('initialpose:', initialpose)
        
        print('For this courswork you need to update the code in pf.py based on the lab sheet')

        # initialise particle cloud array
        #pose_array = PoseArray()

        # Set particle cloud to initialpose plus noise
        # generate and append particles to particle cloud array
        
        #return pose_array

 
    
    def update_particle_cloud(self, scan):
        print('int2')
        # Update particlecloud, given map and laser scan


    def estimate_pose(self):
        print('in3')
        # Create new estimated pose, given particle cloud
        # E.g. just average the location and orientation values of each of
        # the particles and return this.
        
        # Better approximations could be made by doing some simple clustering,
        # e.g. taking the average location of half the particles after 
        # throwing away any which are outliers

